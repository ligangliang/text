//
//  ViewController.m
//  7777
//
//  Created by hzlh on 16/4/1.
//  Copyright © 2016年 lgl. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

{
    UIImageView *_view;


}

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view.image=[UIImage imageNamed:@"LOGO120"];
    [self.view addSubview:_view];

    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];
    _view = [[UIImageView alloc]initWithFrame: (CGRectMake(0, 0, 320, 480))];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
