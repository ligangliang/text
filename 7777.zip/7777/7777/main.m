//
//  main.m
//  7777
//
//  Created by hzlh on 16/4/1.
//  Copyright © 2016年 lgl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
